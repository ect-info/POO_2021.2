# -*- coding: utf-8 -*-

import tkinter as tk
from calculadora_view import *
from calculadora_model import *

class CalculadoraController:
    '''
    Controlador: informa ao Modelo as operações a serem realizadas
    e recupera o resultado para atualizar o View.
    É o objeto aplicação de fato; aquele que controla as ações.
    '''

    # lista de estados válidos (não usada)
    estados = ('num1', 'num2', 'res_ok')

    def __init__(self):
        self.model = None # inicialmente o controlador não tem view e nem model associados
        self.view = None

        self.root = tk.Tk() # cria janela principal Tk
        self.root.title('Calculadora TK')
        self.root.geometry('300x300')

        self.estado = 'num1' # estado atual do controlador
        self.op = None
        self.var_texto = tk.StringVar() # texto com expressão a ser calculada

    def inicializa(self, model, view):
        '''
        Método faz parte da interface pública: atribui view e model
        e em seguida, configura o controlador com o view e model.
        '''
        self.model = model
        self.view = view
        self._configura()


    def _configura(self):
        '''Método privado: configura ações para a visualização (eventos Tk)'''
        self.view.ent_texto['textvariable'] = self.var_texto

        self.view.botoes_num['0']['command'] = lambda: self._processa_entrada(0)
        self.view.botoes_num['1']['command'] = lambda: self._processa_entrada(1)
        self.view.botoes_num['2']['command'] = lambda: self._processa_entrada(2)
        self.view.botoes_num['3']['command'] = lambda: self._processa_entrada(3)
        self.view.botoes_num['4']['command'] = lambda: self._processa_entrada(4)
        self.view.botoes_num['5']['command'] = lambda: self._processa_entrada(5)
        self.view.botoes_num['6']['command'] = lambda: self._processa_entrada(6)
        self.view.botoes_num['7']['command'] = lambda: self._processa_entrada(7)
        self.view.botoes_num['8']['command'] = lambda: self._processa_entrada(8)
        self.view.botoes_num['9']['command'] = lambda: self._processa_entrada(9)

        self.view.botoes_op['+']['command'] = lambda: self._processa_entrada('+')
        self.view.botoes_op['-']['command'] = lambda: self._processa_entrada('-')
        self.view.botoes_op['*']['command'] = lambda: self._processa_entrada('*')
        self.view.botoes_op['=']['command'] = lambda: self._processa_entrada('=')

    def executa(self):
        '''Método principal da interface pública da classe.'''
        tk.mainloop()

    def _processa_entrada(self, par):
        '''
        Callback da interface gráfica:
        atualiza a view com os dígitos/botões pressionados
        e chama o modelo para calcular o resultado.
        Após isto, exibe o resultado na view.
        '''

        # aguardando 1o. operando
        if self.estado == 'num1':
            # botao com digito pressionado
            if type(par) == int:
                self.var_texto.set(self.var_texto.get() + str(par))
            # botao com operador pressionado
            else:
                conteudo = self.var_texto.get()
                if conteudo.isdigit():
                    self.op = par
                    self.model.operando1 = int(conteudo)
                    self.estado = 'num2'
                    self.var_texto.set('')
                    self.view.botoes_op[self.op]['relief'] = tk.SUNKEN

        # aguardando 2o. operando
        elif self.estado == 'num2':
            # botao com digito pressionado
            if type(par) == int:
                self.var_texto.set(self.var_texto.get() + str(par))
            # botao com operador pressionado
            else:
                conteudo = self.var_texto.get()
                if conteudo.isdigit():
                    self.model.operando2 = int(conteudo)
                    self.var_texto.set(str(self.model.opera(self.op)))
                    self.view.botoes_op[self.op]['relief'] = tk.RAISED
                    self.estado = 'res_ok'

        # resultado foi calculado anteriormente
        elif self.estado == 'res_ok':
            # botao com digito pressionado
            if type(par) == int:
                self.var_texto.set(str(par))
                self.estado = 'num1'

if __name__ == "__main__":

    # cria controller
    controller = CalculadoraController()

    # cria modelo
    model = CalculadoraModel()

    # cria view
    view = CalculadoraView(controller.root)

    # chama os métodos necessários do controller para inicar a aplicação
    controller.inicializa(model, view)
    controller.executa()