# -*- coding: utf-8 -*-

import tkinter as tk

class CalculadoraView:
    '''View: interface gráfica Tkinter para calculadora'''

    def __init__(self, root):
        self.root = root # widget mestre

        self.botoes_num = {}
        self.botoes_op = {}

        self._inicializa_gui()

    def _inicializa_gui(self):
        # frame interno
        frame1 = tk.Frame(self.root, bd=2, relief=tk.SUNKEN)
        frame1.pack(expand=True, fill=tk.BOTH)

        # entrada de texto
        self.ent_texto = tk.Entry(frame1)
        self.ent_texto.pack(side=tk.TOP, fill=tk.X)

        # frame com grupo de botões
        frame2 = tk.Frame(frame1, bd=5, relief=tk.SUNKEN, bg='brown')
        frame2.pack(expand=True, fill=tk.BOTH)

        # 7 8 9
        self.botoes_num['7'] = tk.Button(frame2, text="7")
        self.botoes_num['7'].grid(row=0, column=0, sticky="NSWE")

        self.botoes_num['8'] = tk.Button(frame2, text="8")
        self.botoes_num['8'].grid(row=0, column=1, sticky="NSWE")

        self.botoes_num['9'] = tk.Button(frame2, text="9")
        self.botoes_num['9'].grid(row=0, column=2, sticky="NSWE")

        # 4 5 6
        self.botoes_num['4'] = tk.Button(frame2, text="4")
        self.botoes_num['4'].grid(row=1, column=0, sticky="NSWE")

        self.botoes_num['5'] = tk.Button(frame2, text="5")
        self.botoes_num['5'].grid(row=1, column=1, sticky="NSWE")

        self.botoes_num['6'] = tk.Button(frame2, text="6")
        self.botoes_num['6'].grid(row=1, column=2, sticky="NSWE")

        # 1 2 3
        self.botoes_num['1'] = tk.Button(frame2, text="1")
        self.botoes_num['1'].grid(row=2, column=0, sticky="NSWE")

        self.botoes_num['2'] = tk.Button(frame2, text="2")
        self.botoes_num['2'].grid(row=2, column=1, sticky="NSWE")

        self.botoes_num['3'] = tk.Button(frame2, text="3")
        self.botoes_num['3'].grid(row=2, column=2, sticky="NSWE")

        # 0  = 
        self.botoes_num['0'] = tk.Button(frame2, text="0")
        self.botoes_num['0'].grid(row=3, column=0, columnspan=2, sticky="NSWE")

        # operações
        self.botoes_op['+'] = tk.Button(frame2, text="+")
        self.botoes_op['+'].grid(row=0, column=3, sticky="NSWE")

        self.botoes_op['-']= tk.Button(frame2, text="-")
        self.botoes_op['-'].grid(row=1, column=3, sticky="NSWE")

        self.botoes_op['*'] = tk.Button(frame2, text="*")
        self.botoes_op['*'].grid(row=2, column=3, sticky="NSWE")

        self.botoes_op['='] = tk.Button(frame2, text="=")
        self.botoes_op['='].grid(row=3, column=2, columnspan=2, sticky="NSWE")

        # configura linhas e colunas quanto ao redimensionamento
        frame2.rowconfigure(0, weight=1)
        frame2.rowconfigure(1, weight=1)
        frame2.rowconfigure(2, weight=1)
        frame2.rowconfigure(3, weight=1)
        frame2.columnconfigure(0, weight=1)
        frame2.columnconfigure(1, weight=1)
        frame2.columnconfigure(2, weight=1)
        frame2.columnconfigure(3, weight=1)

if __name__ == "__main__":

    # cria janela principal Tk apenas para teste
    root = tk.Tk()
    root.geometry('300x300')
    root.title('Teste GUI')

    # instancia o view
    c = CalculadoraView(root)

    # inicializa aplicação Tk -> a janela deve aparecer,
    # mas não deve reagir aos eventos
    tk.mainloop()