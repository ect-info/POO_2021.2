# -*- coding: utf-8 -*-

class CalculadoraModel:
    '''Modelo: realiza operações aritméticas básicas''' 

    def __init__(self):
        self._operando1 = None
        self._operando2 = None

    @property
    def operando1(self):
        return self._operando1
    
    @operando1.setter
    def operando1(self, num):
        self._operando1 = num

    @property
    def operando2(self):
        return self._operando2
    
    @operando2.setter
    def operando2(self, num):
        self._operando2 = num
    
    def opera(self, op):
        if op == '+':
            return self.operando1 + self.operando2
        if op == '-':
            return self.operando1 - self.operando2
        if op == '*':
            return self.operando1 * self.operando2